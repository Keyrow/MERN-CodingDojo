import React from 'react';
import { Link } from '@reach/router';

const PageFour = props => {
    return (
        <div>
            <h1>Page 4</h1>
        </div>
    )
}

export default PageFour;