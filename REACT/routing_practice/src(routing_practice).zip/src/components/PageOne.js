import React from 'react';
import { Link } from '@reach/router';

const PageOne = props => {
    return (
        <div>
            <h1>Welcome</h1>
        </div>
    )
}

export default PageOne;