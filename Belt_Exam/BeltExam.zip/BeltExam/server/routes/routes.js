const controller = require('../controllers/pet.controller');

module.exports = function (app) {
    //Read Routes --> app.get
    app.get('/api/pets', controller.allPets);
    app.get('/api/pets/:id', controller.onePet);
    //Create Routes --> app.post
    app.post('/api/pets', controller.newPet);
    // Update Routes --> app.patch
    app.put('/api/pets/:id', controller.editPet);
    // Delete Routes --> app.delete
    app.delete('/api/pets/:id', controller.deletePet);
}